import React, { useState } from 'react';
import { View, ScrollView, Alert, Pressable } from 'react-native';
import { Link, router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ScreenContainer';
import { AppText } from '@/components/AppText';
import { AppTextField } from '@/components/AppTextField';
import { AppButton } from '@/components/AppButton';
import { PasswordChecklist } from '@/components/PasswordChecklist';
import { AuthHeroBackground } from '@/components/AuthHeroBackground';
import { WaveCard } from '@/components/WaveCard';
import { useAuth } from '@/auth/AuthContext';
import { useTheme } from '@/theme/ThemeProvider';
import { UserRole } from '@/api/types';
import { isPasswordValid, passwordStrength, isValidEmailFormat, isValidUsername } from '@/utils/validation';
import { seedProfileUsername } from '@/api/profile';
import { getInstitutionForEmail } from '@/api/institutions';
import { institutionThemeOverrides } from '@/theme/colors';

const PORTALS: Array<{ value: Extract<UserRole, 'student' | 'alumni'>; label: string; icon: keyof typeof Ionicons.glyphMap }> = [
  { value: 'student', label: 'Student Portal', icon: 'school' },
  { value: 'alumni', label: 'Alumni Circle', icon: 'star' },
];

export default function RegisterScreen() {
  const { colors, radius, spacing, isDark } = useTheme();
  const { register } = useAuth();
  const [portal, setPortal] = useState<Extract<UserRole, 'student' | 'alumni'>>('student');
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const passwordValid = isPasswordValid(password);
  const strength = passwordStrength(password);
  const emailTouched = email.length > 0;
  const emailFormatValid = isValidEmailFormat(email);
  const matchedInstitution = getInstitutionForEmail(email);
  const usernameTouched = username.length > 0;
  const usernameValid = isValidUsername(username);

  // Live-preview the matched university's own brand color as soon as
  // the person types a recognized school email — the same colors
  // ThemeProvider applies globally once they're logged in
  // (src/theme/colors.ts's institutionThemeOverrides), just surfaced a
  // moment earlier since there's no profile yet during registration.
  const institutionOverride = matchedInstitution ? institutionThemeOverrides[matchedInstitution.code] : undefined;
  const heroFromColor = institutionOverride ? (isDark ? institutionOverride.dark.brandPrimaryPressed : institutionOverride.light.brandPrimaryPressed) : undefined;
  const heroToColor = institutionOverride ? (isDark ? institutionOverride.dark.brandPrimary : institutionOverride.light.brandPrimary) : undefined;

  const canSubmit =
    fullName.trim().length > 1 && emailFormatValid && passwordValid && usernameValid && acceptedTerms;

  async function handleRegister() {
    if (!canSubmit) return;
    setSubmitting(true);
    try {
      const createdUser = await register({
        fullName: fullName.trim(),
        username,
        email: email.trim(),
        password,
        userType: portal,
      });
      // Anyone can register with any real email. Only a matching
      // launch-university domain auto-verifies the account (the tick);
      // everyone else starts unverified and can apply later from their
      // Profile by submitting documents for manual review.
      seedProfileUsername(createdUser, username, matchedInstitution ?? undefined);
      router.replace('/');
    } catch {
      Alert.alert('Registration failed', 'Please check your details and try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <ScreenContainer noPadding glow={false}>
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingBottom: spacing.xxl }}>
        <AuthHeroBackground height={140} fromColor={heroFromColor} toColor={heroToColor}>
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'flex-end', paddingBottom: spacing.lg }}>
            <AppText variant="h1" weight="bold" tone="inverse">
              Join Lioris
            </AppText>
            {matchedInstitution ? (
              <AppText tone="inverse" weight="semiBold" style={{ opacity: 0.9, marginTop: 2 }}>
                at {matchedInstitution.name}
              </AppText>
            ) : null}
          </View>
        </AuthHeroBackground>

        <WaveCard>
          <View style={{ flexDirection: 'row', backgroundColor: colors.divider, borderRadius: radius.pill, padding: 4, marginBottom: spacing.lg }}>
          {PORTALS.map((p) => {
            const selected = portal === p.value;
            return (
              <Pressable
                key={p.value}
                onPress={() => setPortal(p.value)}
                accessibilityRole="tab"
                accessibilityState={{ selected }}
                accessibilityLabel={p.label}
                style={{
                  flex: 1,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 6,
                  paddingVertical: spacing.sm,
                  borderRadius: radius.pill,
                  backgroundColor: selected ? colors.brandPrimary : 'transparent',
                }}
              >
                <Ionicons name={p.icon} size={14} color={selected ? '#FFFFFF' : colors.textSecondary} />
                <AppText variant="bodySmall" weight="bold" tone={selected ? 'inverse' : 'secondary'}>
                  {p.label}
                </AppText>
              </Pressable>
            );
          })}
        </View>

        <AppText variant="h1" weight="bold" style={{ marginBottom: spacing.xs }}>
          {portal === 'student' ? 'Create Student Workspace' : 'Create Alumni Workspace'}
        </AppText>
        <AppText tone="secondary" style={{ marginBottom: spacing.lg }}>
          UNILAG, UI, and FUNAAB emails are verified automatically. Any other email still works —
          you can apply for the verified tick afterward.
        </AppText>

        <View style={{ flexDirection: 'row', gap: 6, marginBottom: spacing.lg }}>
          <Ionicons name="alert-circle" size={14} color={colors.critical} style={{ marginTop: 2 }} />
          <AppText variant="caption" style={{ color: colors.critical, flex: 1 }}>
            Security Policy: password must be 12+ characters with uppercase, lowercase, a
            number, and a special character.
          </AppText>
        </View>

        <AppTextField
          label="School Email"
          autoCapitalize="none"
          keyboardType="email-address"
          value={email}
          onChangeText={setEmail}
          placeholder="you@unilag.edu.ng or any email"
          error={emailTouched && !emailFormatValid ? 'Enter a valid email address' : undefined}
        />
        {emailTouched && emailFormatValid && matchedInstitution ? (
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: -spacing.sm, marginBottom: spacing.lg }}>
            <Ionicons name="checkmark-circle" size={14} color={colors.success} />
            <AppText variant="bodySmall" style={{ color: colors.success }}>
              Registering at {matchedInstitution.name} — you'll be verified automatically.
            </AppText>
          </View>
        ) : null}
        {emailTouched && emailFormatValid && !matchedInstitution ? (
          <View style={{ flexDirection: 'row', gap: 6, marginTop: -spacing.sm, marginBottom: spacing.lg }}>
            <Ionicons name="information-circle" size={14} color={colors.brandPrimary} style={{ marginTop: 2 }} />
            <AppText variant="caption" tone="secondary" style={{ flex: 1 }}>
              We don't recognize this school domain yet, but you can still register. You won't
              have the verified tick until you apply with supporting documents from your Profile
              afterward.
            </AppText>
          </View>
        ) : null}

        <View>
          <AppTextField
            label="Password (Min 12 characters)"
            secureTextEntry={!showPassword}
            value={password}
            onChangeText={setPassword}
            placeholder="••••••••••••"
          />
          <Pressable
            onPress={() => setShowPassword((v) => !v)}
            accessibilityRole="button"
            accessibilityLabel={showPassword ? 'Hide password' : 'Show password'}
            style={{ position: 'absolute', right: spacing.md, top: 40 }}
            hitSlop={8}
          >
            <Ionicons name={showPassword ? 'eye' : 'eye-off'} size={18} color={colors.textSecondary} />
          </Pressable>
        </View>

        {password.length > 0 ? (
          <View style={{ marginTop: -spacing.sm, marginBottom: spacing.sm }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 }}>
              <AppText
                variant="caption"
                weight="bold"
                style={{
                  color:
                    strength.color === 'critical'
                      ? colors.critical
                      : strength.color === 'warning'
                        ? colors.warning
                        : strength.color === 'success'
                          ? colors.success
                          : colors.brandPrimary,
                }}
              >
                {strength.label} strength
              </AppText>
              <AppText variant="caption" tone="secondary">
                {password.length} chars
              </AppText>
            </View>
            <View style={{ height: 4, borderRadius: 2, backgroundColor: colors.divider }}>
              <View
                style={{
                  height: 4,
                  borderRadius: 2,
                  width: `${strength.score}%`,
                  backgroundColor:
                    strength.color === 'critical'
                      ? colors.critical
                      : strength.color === 'warning'
                        ? colors.warning
                        : strength.color === 'success'
                          ? colors.success
                          : colors.brandPrimary,
                }}
              />
            </View>
          </View>
        ) : null}
        {password.length > 0 ? <PasswordChecklist password={password} /> : null}

        <AppTextField
          label="Choose Username (@handle)"
          autoCapitalize="none"
          value={username}
          onChangeText={setUsername}
          placeholder="e.g. ineme.17"
          error={usernameTouched && !usernameValid ? '3-24 characters: letters, numbers, dots, underscores' : undefined}
        />

        <AppTextField label="Display Full Name" value={fullName} onChangeText={setFullName} placeholder="Inem Light" />

        <Pressable
          onPress={() => setAcceptedTerms((v) => !v)}
          accessibilityRole="checkbox"
          accessibilityState={{ checked: acceptedTerms }}
          accessibilityLabel="I accept the Privacy Policy, Terms of Service, and Community Rules"
          style={{ flexDirection: 'row', gap: spacing.md, marginBottom: spacing.lg, marginTop: spacing.sm }}
        >
          <Ionicons
            name={acceptedTerms ? 'checkbox' : 'square-outline'}
            size={20}
            color={acceptedTerms ? colors.brandPrimary : colors.textSecondary}
          />
          <AppText variant="bodySmall" style={{ flex: 1 }}>
            I accept the Privacy Policy, Terms of Service, and Community Rules.
          </AppText>
        </Pressable>

        <AppButton label="Configure & Join" onPress={handleRegister} loading={submitting} disabled={!canSubmit} fullWidth />

        <View style={{ alignItems: 'center', marginTop: spacing.lg }}>
          <Link href="/(auth)/login">
            <AppText tone="brand" weight="semiBold">
              Already have an account? Log In
            </AppText>
          </Link>
        </View>
        </WaveCard>
      </ScrollView>
    </ScreenContainer>
  );
}
