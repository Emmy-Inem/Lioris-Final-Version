import type { ExpoConfig, ConfigContext } from 'expo/config';

// Values are pulled from the shell / EAS build profile environment.
// See eas.json for the per-environment variable sets and .env.example
// for local development.
const API_BASE_URL = process.env.API_BASE_URL ?? 'https://api.dev.lioris.app';
const WS_BASE_URL = process.env.WS_BASE_URL ?? 'wss://api.dev.lioris.app/realtime';
const APP_ENV = process.env.APP_ENV ?? 'development';

export default ({ config }: ConfigContext): ExpoConfig => ({
  ...config,
  name: APP_ENV === 'production' ? 'Lioris' : `Lioris (${APP_ENV})`,
  slug: 'lioris',
  scheme: 'lioris',
  version: '1.0.0',
  orientation: 'portrait',
  icon: './assets/images/icon.png',
  userInterfaceStyle: 'automatic', // supports Light + Dark mode, per PRD section 8 (Themes)
  assetBundlePatterns: ['**/*'],
  ios: {
    supportsTablet: false,
    bundleIdentifier: 'app.lioris.mobile',
    infoPlist: {
      NSCameraUsageDescription:
        'Lioris uses your camera to take a profile photo during onboarding.',
      NSPhotoLibraryUsageDescription:
        'Lioris uses your photo library so you can choose a profile photo.',
      ITSAppUsesNonExemptEncryption: false,
    },
  },
  android: {
    package: 'app.lioris.mobile',
    adaptiveIcon: {
      foregroundImage: './assets/images/android-icon-foreground.png',
      backgroundColor: '#0B1220',
    },
    permissions: ['CAMERA', 'READ_EXTERNAL_STORAGE', 'POST_NOTIFICATIONS'],
    // googleServicesFile: './google-services.json', // add once FCM/Firebase project exists
  },
  web: {
    favicon: './assets/images/favicon.png',
    bundler: 'metro',
  },
  plugins: [
    'expo-router',
    'expo-secure-store',
    'expo-font',
    [
      'expo-notifications',
      {
        icon: './assets/images/notification-icon.png',
        color: '#2F6FED', // brand primary blue
      },
    ],
    [
      'expo-splash-screen',
      {
        image: './assets/images/splash.png',
        imageWidth: 200,
        resizeMode: 'contain',
        backgroundColor: '#0B1220',
      },
    ],
  ],
  extra: {
    apiBaseUrl: API_BASE_URL,
    wsBaseUrl: WS_BASE_URL,
    appEnv: APP_ENV,
    eas: {
      projectId: 'REPLACE_WITH_EAS_PROJECT_ID',
    },
  },
  experiments: {
    typedRoutes: true,
  },
});
